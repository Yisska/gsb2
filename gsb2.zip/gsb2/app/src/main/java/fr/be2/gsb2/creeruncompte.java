package fr.be2.gsb2;

import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;

public class creeruncompte extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_creeruncompte);
    }
}